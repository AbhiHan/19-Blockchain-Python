import json
import subprocess 

command = './hd-wallet-derive/hd-wallet-derive.php -g --mnemonic="fall cook horse hockey never lift custom drill half thank stadium two" --cols=path.address.privkey.pubkey'

p=subprocess.Popen(command, stdout=subproces.PIPE, shell=True)

(output, err) = p.communicate()
p_status=p.wait()

doc = json.loads(output)
print(doc)
print("doc[0] address = ", doc[0]['address'])